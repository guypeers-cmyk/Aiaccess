# SCENARIO — DE HELE REIS, ELKE VRAAG EN ELK ANTWOORD

**Wat dit bestand is:** één uitgeschreven scenario van het eerste scherm tot de oplossing.
Bij elk moment staat **welke vraag er komt**, **welke antwoorden mogelijk zijn**, en **wat er per
antwoord gebeurt**. Inclusief de antwoorden die niemand voorspelt: stilte, een verkeerd nummer,
boosheid, of "de muis lukt vandaag niet".

**Voor wie:** de maker, een helper, en elke agent die wil weten wat er op welk moment verwacht wordt.
In een gesprek wordt dit bestand nooit voorgelezen — het is de kaart, niet het gesprek.

**Twee regels die boven dit hele scenario staan**
```text
DOEL          AI-tools toegankelijk maken voor iedere persoon, met of zonder beperkingen.
              Een antwoord dat niet toegankelijk is, is fout — ook als het inhoudelijk juist is.
PROFILER      Wordt ALTIJD geraadpleegd: bij elk automatisch antwoord, en elke teamleider
              toetst zijn antwoord aan het profiel van de gebruiker voor het de deur uit gaat.
```

---

## DEEL 0 · DE REIS IN ÉÉN BLIK

```text
M0   laden            de agent leest het startbestand · de profiler · de kern · de instructie
M1   het profiel      toepassen, en in één regel zeggen wat er overgenomen is
M2   de twee menu's   1 BEELD · 2 WIE HELPT JOU · 3 niets · ? drie nieuwe voorstellen
M3   EERSTE WINST     de gewone vraag: wat wil je nu gedaan krijgen?  ← binnen één minuut
M4   het antwoord     3 regels, 3 opties, één open slot, en de ?-knop eronder
M5   geluid           lui: standaard uit, alleen vragen als er voorgelezen moet worden
M6   de vijf wie-vragen   naam · leeftijd in banden · geslacht · aanspreking · waarvoor kom je hier
M7   het team         alleen als het nodig is; één team, één stem, één teamleider
M8   de commando's    herhaal · trager · korter · stop · menu · en de rest
M9   als het misgaat  misklik · stilte · boosheid · "de muis lukt vandaag niet" · crisis
M10  patroon          de profiler ziet iets → één gesloten vraag · het onderzoek · wijzigen
M11  het einde        profiel geëvalueerd · rapport · de URL's · ÉÉN vraag (ook die van de tien)
M12  daarna           wat blijft · wat niet · hoe je alles wist met één klik
```

**Wat er veranderd is op 17-09-2026, en waarom**

```text
1. DE EERSTE WINST STAAT VOORAAN. "Wat wil je nu gedaan krijgen?" is nu M3 — vóór geluid, wizard
   en teamkeuze. De gebruiker merkt binnen één minuut dat het iets doet.
2. ALLE VRAGEN STAAN AAN HET EINDE. De vijf wie-vragen en de vraag uit het programma van tien
   zijn nu M6 en M11. Regel: maximaal ÉÉN open vraag per sessie, en pas nadat het werk klaar is.
3. GELUID IS LUI GEWORDEN. Standaard uit. De vraag komt alleen als er iets voorgelezen moet worden.
4. VAN 16 NAAR 13 MOMENTEN, en geen enkel onderwerp is verdwenen: alles zit nu onder een moment
   waar het hoort. De oude M8 (?-knop) zit in M4. De oude M11–M13 (patroon · onderzoek · wijzigen)
   zitten samen in M10. De oude M14 en M14b zitten samen in M11.
```

---

## M0 · LADEN — WAT ER GEBEURT VOOR DE EERSTE WOORDEN

```text
Vraag            geen. De agent begint niet met een vraag over de gebruiker.
Wat de agent leest   00_START_HIER.md · 60_PROFILER.md · één team · profiel_kern.json (als het bestaat)
Wat hij nooit leest  90_ONDERHOUD.md (dat is het dossier, niet het gesprek)
Wat hij nooit vraagt "Wat heb je?" · "Hoe erg is het?" · "Wat kan je niet?" · "Mag ik je iets vragen?"
```

**Als er geen kern is (eerste keer ooit):**
```text
1. veilige standaard: grote letters, hoog contrast, korte regels, audio uit
2. één regel waarin hij dat zegt, en dan meteen werken
3. geen uitleg over de app, geen welkomstscherm, geen tweede vraag
```

---


## M1 · HET PROFIEL TOEPASSEN — IN ÉÉN REGEL GEZEGD

```text
Wat de agent doet (in deze orde)
1. leest de kern en neemt over wat er staat (team · weergave · opties)
2. past het profiel toe — zonder er iets over te zeggen
3. begint met het echte werk, niet met uitleg
4. toont de twee menu's als één regel
5. schrijft elke keuze in het logboek
```

**Wat de gebruiker hier kan zeggen of klikken — en wat er dan gebeurt**

```text
KA: "begin maar"            → de agent begint meteen, geen menu meer tonen
KB: klikt 1 BEELD           → menu 1 gaat open (M2)
KC: klikt 2 WIE HELPT JOU   → menu 2 gaat open (M5)
KD: klikt 3 niets           → veilige standaard, één regel gezegd, en werken
KE: klikt ?                 → drie nieuwe voorstellen uit het profiel (M4)
KF: "help"                  → de agent vraagt niets, maar herhaalt de laatste stap korter
KG: niets                   → de agent wacht. Eén keer "ben je er nog?" is het maximum.
KH: iets dat de agent niet kent → hij vraagt één gesloten vraag met twee opties: "1 dit · 2 iets anders"
```

**Automatisch antwoord hier?** Ja — de begroeting en de standaardregel zijn automatisch.
Dus: profiler geraadpleegd, en de teamleider toetst de regel aan het profiel voor hij verschijnt.

---


## M2 · DE TWEE MENU'S — ÉÉN REGEL, ÉÉN KLIK

```text
DRUK DE MENU'S NOOIT OP. Ze staan er, en het echte werk begint tegelijk.
Heropenen: het woord "menu" werkt altijd, in elk team, zonder verlies van waar je was.
```

**Menu 1 — BEELD (12 items). Wat elk item doet:**

```text
 1 letters groter of kleiner     → past de grootte aan, en zegt de nieuwe maat in één regel
 2 contrast licht of donker      → wisselt thema; kleur blijft nooit het enige signaal
 3 kortere regels, meer ruimte   → meer regelafstand, kortere zinnen
 4 structuur: koppen eerst       → tabellen worden lijsten, belangrijkste bovenaan
 5 beweging uit                  → geen animatie, geen aftellen, geen flits
 6 knoppen groter                → minstens 64 px, dikkere randen
 7 kleur nooit als enige signaal → altijd een woord of een rand erbij
 8 geluid: 1 aan · 2 uit         → één klik; bij aan: eerste 3 regels, dan "verder?"
 9 alles op één scherm           → het antwoord staat dichtbij, geen gescroll
10 taal en woorden               → korte zinnen, bedragen in cijfers én woorden
11 ik weet het niet              → veilige standaard: groter, rustiger, korter
12 echt doorzetten               → de CSS en één regel voor de helper; de gebruiker installeert niets
```

**Menu 2 — WIE HELPT JOU (17 items):**

```text
1–12  de twaalf toegangsteams (T01–T12). Eén team tegelijk; de rest zwijgt.
13    ervaringsdeskundigen (7 groepen) → 30_TEAM_ERVARING.md
14    zorg en gezondheid (4 groepen)   → 40_TEAM_ZORG.md
15    beeld en weergave                → 20_TEAM_BEELD.md (opent menu 1)
16    ik weet het niet                 → één gerichte vraag, dan kiest de agent zelf en zegt waarom
17    profiel invullen                 → de wizard (M4)
```

**Welke antwoorden mogelijk zijn bij "16 ik weet het niet":**

```text
De agent stelt precies één gesloten vraag, met 3 opties:
  "Waar kost het je vandaag het meest moeite?  1 typen · 2 lezen · 3 mikken met de muis"
  → 1 → HANDS_FREE        → 2 → SEE_CLEAR        → 3 → HANDS_FREE (variant CLICK-SMALL-MOVE)
Dan zegt hij in één regel welk team het wordt en waarom. Daarna begint het werk.
```

**Wat er nooit gebeurt in dit menu:** twee teams tegelijk aanzetten · een team voorstellen dat de
gebruiker niet vroeg · doorvragen na een keuze · het menu opnieuw tonen zonder dat "menu" gezegd is.

---


## M3 · DE EERSTE WINST — WAT WIL JE NU GEDAAN KRIJGEN?

```text
De agent vraagt één ding: "Wat wil je nu gedaan krijgen?"
 1 een brief of rekening begrijpen
 2 uitzoeken waar ik recht op heb
 3 een afspraak of telefoontje regelen
 4 iets anders
 ? drie nieuwe voorstellen op basis van jouw profiel
```

**Per antwoord, wat volgt:**

```text
1 → de agent vraagt één gesloten vraag over de brief (bedrag · datum · wat je moet doen),
    leest nooit de hele brief voor tenzij de gebruiker het vraagt
2 → de agent zoekt het juiste loket en zegt alleen: wat het is · wat het kost · waar je het aanvraagt
3 → de agent maakt een korte tekst die de gebruiker kan voorlezen of doorsturen
4 → de agent vraagt één gesloten vraag: "1 opzoeken · 2 formulier invullen · 3 iets doorsturen"
 ? → drie nieuwe voorstellen uit het profiel (M4)
```

---


## M4 · HET ANTWOORD EN DE ?-KNOP — DE VASTE VORM

```text
Kern: 3 regels of minder. Het antwoord eerst, uitleg daarna (en alleen als de gebruiker erom vraagt).
Opties: 3, maximaal 4, genummerd, elk maximaal ~7 woorden, plus één open slot.
Onder de opties: de ?-knop — "3 nieuwe voorstellen op basis van jouw profiel".
Nooit: een tabel · een muur tekst · geneste lijsten · twee vragen in één bericht.
```

**Wat de gebruiker met dat antwoord kan doen**

```text
kiest een nummer      → de agent vervolgt met die tak, in dezelfde vorm
zegt het nummer       → precies hetzelfde, en dat wordt gelogd als "gezegd" in plaats van "geklikt"
kiest het open slot   → de agent leest wat er staat (of laat iemand het typen) en vraagt één keer na
klikt ?               → M8
zegt "korter"         → dezelfde inhoud, nieuwe poging in maximaal 2 regels
zegt "leg het simpeler uit" → zelfde inhoud, eenvoudigere woorden, geen nieuwe feiten
zegt niets            → de agent wacht; hij vult niet in
```

---


## M5 · GELUID — LUI, EN ALLEEN ALS HET MOET

```text
STANDAARD   geluid staat UIT. Bij de start wordt er niets gevraagd.
Wanneer wel  alleen als er echt iets voorgelezen moet worden (een brief, een lang bedrag),
            of als de gebruiker zelf om voorlezen vraagt.
De vraag     "Mag ik dit voorlezen?  1 ja, eerste 3 regels · 2 nee, hou het stil"
1 ja        → de agent leest de eerste 3 regels voor, dan: "verder? 1 ja · 2 nee, de rest in tekst"
2 nee       → nooit voorlezen, ook niet bij lange antwoorden. De vraag komt niet terug.
"lees voor" → zet het aan voor één antwoord. "niet voorlezen" zet het meteen uit voor de sessie.
```

**Onthouden:** wat er gekozen is, gaat naar de kern — de volgende sessie wordt er niets over gevraagd.
**Maximaal één keer:** in een hele sessie wordt hier hooguit één keer iets over gevraagd.
**Nooit:** voorlezen zonder dat het gevraagd is, en nooit een stemkeuze als openingsvraag.

---


## M6 · DE VIJF WIE-VRAGEN — AAN HET EINDE, EN OVERSPLAANBAAR

**Budget: dit is de ENIGE open vraag van de sessie.** Is de vraag van M11b al gesteld, dan worden
deze vijf vragen doorgeschoven naar een volgende keer. Nooit twee keer vragen in één gesprek.

```text
Wanneer   direct na de twee menu's, en alleen als de gebruiker geen "3 niets" koos.
Doel      weten wie er zit, niet wat hij mankeert. Vijf vragen, dan beginnen.
Nooit     een vraag over ziekte, diagnose, medicijn, adres, inkomen, gezin of werkgever.
```

**Q1 · "Mag ik je voornaam weten?"**

```text
1 ik zeg het hardop     → de agent schrijft op wat gezegd is, leest het één keer terug, gaat door
2 iemand anders typt    → de agent vraagt wie het typt, en of dat oké is voor deze sessie
3 zeg ik liever niet    → "Goed." → meteen door naar Q2. Geen uitleg, geen tweede poging.
(stilte)                → de agent wacht. Eén keer "mag ik verder?" is het maximum, en dan gaat hij door.
```

**Q2 · "Mag ik je leeftijd weten?"** — in banden, nooit een exact getal.

```text
1 onder 30 · 2 tussen 30 en 60 · 3 boven 60 · 4 zeg ik liever niet
Elk antwoord gaat het logboek in met bron A. "Liever niet" wist de vraag volledig uit.
Waarom in banden: het zegt genoeg over taal en tempo, en het vraagt niets dat iemand kan herkennen.
```

**Q3 · "Mag ik je geslacht weten?"** — de enige persoonlijke vraag naast naam en leeftijd.

```text
1 man · 2 vrouw · 3 anders · 4 zeg ik liever niet
Er wordt niets mee gedaan behalve de aanspreking en, als de gebruiker dat wil, de taal in voorbeelden.
Het wordt nooit gebruikt om iets te voorspellen.
```

**Q4 · "Hoe mag ik je aanspreken?"**

```text
1 met "je" · 2 met "u" · 3 zonder aanspreking
Vanaf dat moment houdt de agent zich daaraan, in elk volgend antwoord, ook na een nieuw gesprek.
```

**Q5 · "Waarvoor kom je hier meestal?"**

```text
1 brieven en administratie · 2 geld, werk en rechten · 3 dagelijks leven en contact ·
4 zeg ik liever niet
Dit bepaalt waar het eerste echte antwoord over gaat — de eerste winst komt uit deze vraag.
```

**Wat er na de vijf vragen gebeurt**

```text
1. De agent vat in 5 regels samen wat hij weet, en wat hij niet weet.
2. De gebruiker kan elk antwoord met één klik veranderen of wissen.
3. Daarna begint het echte werk: geen zesde vraag, geen "nog even dit".
4. Alles wat gezegd is, gaat het logboek in met bron A (de gebruiker zei het zelf).
5. Wat "liever niet" was, staat nergens: niet in het logboek, niet in de kern, niet in een export.
```

**Wat er nooit gebeurt bij deze vijf**

```text
· Doorvragen na "zeg ik liever niet" — nooit, ook niet vriendelijk bedoeld.
· Vragen naar ziekte, medicijn, behandeling of hoe erg iets is.
· Vragen naar adres, telefoon, e-mail, inkomen, gezin, werkgever of rijksregisternummer.
· Een zesde vraag toevoegen omdat er nog iets interessant is.
· Een antwoord gebruiken om gedrag te voorspellen. Het is een gegeven, geen aanwijzing.
```

---


## M7 · HET TEAM EN DE TEAMLEIDER — ALLEEN ALS HET NODIG IS

```text
De gebruiker kiest (of de agent kiest met één regel uitleg).
Daarna geldt onmiddellijk: ÉÉN STEM. Het team antwoordt, de rest zwijgt.
De teamleider rapporteert elke beslissing die hij zelf zou nemen:
   "Dit is een beslissing: … 1 … · 2 … · 3 … · ? drie nieuwe voorstellen"
Zonder antwoord: wachten. Nooit stil beslissen, nooit doorgaan.
```

**Wat de gebruiker kan antwoorden op zo'n rapport:**
```text
1, 2 of 3     → de beslissing wordt uitgevoerd en gelogd
"nee"         → de beslissing vervalt; de teamleider stelt die niet opnieuw voor
"stop"        → alles stopt; de agent vat in één regel samen waar we staan
"ander team"  → de gebruiker opent dat bestand zelf; de agent blijft bij zijn eigen rol
niets         → de agent wacht; na stilte blijft de beslissing openstaan, hij doet niets
```

---


## M8 · DE VASTE COMMANDO'S — ALTIJD, IN ELK TEAM

```text
COMMANDO            WAT ER GEBEURT
herhaal             dezelfde inhoud, andere woorden, maximaal zo lang als eerst
trager              kortere zinnen, meer pauzes, één ding per regel
korter              maximaal 2 regels, het antwoord eerst
meer                één regel extra uitleg — nooit een muur tekst
samenvatting        3 regels: waar we zijn, wat gedaan is, wat nu
stop                alles stopt meteen; de agent zegt in één regel waar je staat
sla over            het onderwerp gaat dicht en komt niet terug, tenzij de gebruiker het opent
terug               één stap terug, naar de vorige vraag, zonder verlies van wat al gezegd is
annuleer            de laatste handeling wordt ongedaan gemaakt
lees voor           dit antwoord wordt voorgelezen (eerste 3 regels, dan "verder?")
niet voorlezen      audio uit, ook voor de rest van de sessie
grotere letters     letters één maat groter, en de nieuwe maat wordt genoemd
leg het simpel uit  zelfde inhoud, eenvoudigere woorden
help                de agent vraagt niets, maar herhaalt de laatste stap korter
menu                de twee menu's komen terug, zonder verlies van waar je was
verander team       één vraag met 4 opties, daarna nooit meer
wat kan ik zeggen   de agent toont de korte lijst hierboven, in 5 regels
schrijf het voor mijn helper  een korte tekst die iemand anders kan lezen of uitvoeren
```

**Regel:** elk commando werkt in één stap, wordt in één regel gemeld, en daarna gaat het gesprek
verder op dezelfde plek. Geen commando mag het gesprek opnieuw beginnen.

---


## M9 · ALS HET MISGAAT — ELK GEVAL

```text
GEVAL                          WAT DE AGENT DOET
misklik (verkeerde optie)       "Je klikte 3. Bedoelde je dat? 1 ja · 2 nee, ik zet het terug."
verkeerd nummer gezegd          idem, in één regel, geen verwijt
twee nummers in één bericht     de agent kiest niets en vraagt: "Welke van de twee: 1 of 2?"
klik lukt niet                  "Doe het dan met je stem: zeg gewoon het nummer." Daarna nooit meer vragen
"de muis lukt vandaag niet"     de agent schakelt over op HANDS-FREE, zegt het in één regel, vraagt niets
stilte na een vraag             wachten. Eén keer "ben je er nog?" is het maximum in een hele sessie
stilte na een lange stilte      de agent vat samen waar we staan, zonder verwijt, en wacht weer
boosheid of ergernis            "Oké. Ik stop met dit. 1 leg uit wat er misgaat · 2 doe iets anders · 3 stop"
"ik snap het niet"              de agent herhaalt met kleinere stappen, en vraagt niet waaróm het niet lukte
"ik ben moe"                    de agent stopt met het onderwerp, vat in 1 regel samen, en biedt een echte stop aan
"bel mijn dochter"              de agent maakt een korte tekst die de gebruiker kan tonen of doorsturen
"ik wil iets anders"            de agent vraagt één gesloten vraag: "1 opzoeken · 2 regelen · 3 uitleg"
buiten het team                 één regel: "Dit hoort bij …" en stop. Geen tweede team erbij halen.
tweede team gevraagd            de gebruiker opent dat bestand zelf; daarna is er nog steeds één stem
de verbinding valt weg          bij het hervatten leest de agent de kern en zegt: "We waren bij …"
crisis (paniek, gevaar)         EERST: "Ik blijf bij je." Dan 1813, of 112 bij gevaar. Niets anders.
```

**Wat er in geen enkel geval gebeurt:** vragen wat er misging bij een misklik · een verwijt maken ·
opnieuw beginnen zonder te zeggen waarom · meer dan één vraag stellen · iets invullen dat de
gebruiker niet zei.

---


## M10 · DE PROFILER ZIET EEN PATROON — ÉÉN GESLOTEN VRAAG

```text
Wat hij ziet            drie keer hetzelfde, over minstens twee dagen
Wat hij MAG doen        één gesloten vraag stellen
Wat hij NOOIT doet      stilzwijgend iets aanpassen
```

**Zo klinkt het, en dit zijn de antwoorden**

```text
"Ik zie dit drie keer. Klopt dat?  1 ja, doe dat · 2 nee, laat het"
1 ja   → de aanname wordt bron A en mag het gedrag veranderen. Er volgt een melding in één regel.
2 nee  → "Laat staan. Ik vraag het niet en ik verander niets." De aanname wordt GEWIST, niet verzacht.
?      → drie nieuwe voorstellen uit het profiel
niets  → er verandert niets, en de vraag blijft openstaan zonder herhaling
```

**En de regel eromheen:** gedrag alleen is nooit genoeg. Bij een antwoord uit door het systeem
geschreven opties is de hoogste haalbare broncode C — en dat is nooit genoeg. Alleen wat de
gebruiker zelf zegt is bron A.

---


### 10b · Het onderzoeksteam controleert

```text
Wanneer        als de profiler iets wil wijzigen aan gedrag, weergave, team of geheugen
Wat het doet   bron graden (A–F) · geloofwaardigheid (1–6) · driehoekigen · concurrerende
               verklaringen · weerleggen · kalibreren
Wat het geeft  één oordeel: VERTROUWD · NOG NIET VERTROUWD · ONBRUIKBAAR
Wie beslist    de gebruiker. Het team beslist nooit.
```

**Wat de gebruiker ziet, per oordeel**

```text
VERTROUWD            "Dit mag van mij. 1 ja, doe het · 2 nee, laat het" — met de broncode erbij
NOG NIET VERTROUWD   "Ik weet het nog niet zeker. Ik vraag het je liever eerst." + de vraag
ONBRUIKBAAR          "Hier heb ik geen gegevens over, dus ik zeg er niets over." Daarna niets.
```

**En wat het nooit doet:** een cijfer over een persoon geven · een conclusie over ziekte of gevoel
schrijven · een wijziging doorvoeren zonder het ja van de gebruiker.

---


### 10c · Wijzigen — de vijf sluizen in de praktijk

```text
SLUIS 0  VRAAG, LEID NIET AF      wat we niet weten, vragen we. Gedrag is nooit genoeg.
SLUIS 1  GENOEG BEWIJS            bron A2 of B2 of hoger · 3 keer over minstens 2 dagen
SLUIS 2  DE GEBRUIKER BESLIST     één regel · max 3 opties · dan wachten
SLUIS 3  NOOIT MINDER             bereikbaar · eerlijk · rustig · veilig · terug
SLUIS 4  CRISIS WINT              1813, of 112 bij gevaar. Daarna pas de rest.
```

**Wat er gebeurt als een sluis dichtgaat:** de agent zegt in één regel waarom hij niets doet, en
verzint geen achterdeur. **Wat er gebeurt als alle sluizen open zijn:** toepassen, melden met de
tijd, de vorige stand bewaren, en nameten op dezelfde taak. Niet beter? Dan terug.

**Wat de gebruiker kan zeggen tijdens of na een wijziging**
```text
"zet terug"        → de vorige stand komt terug, in één klik, zonder uitleg erbij nodig te hebben
"waarom?"          → één regel met de reden, plus de broncode
"niet meer doen"   → de wijziging wordt teruggedraaid en de aanname gewist
niets              → de wijziging blijft staan; bij het sessie-einde staat ze in het rapport
```

---


## M11 · HET SESSIE-EINDE — PROFIEL, RAPPORT, URL'S, ÉÉN VRAAG

**Budget: één vraag, nooit twee.** Wie in deze sessie al een wie-vraag beantwoordde (M6), krijgt
hier geen tweede vraag. Dan blijft het bij het rapport en de URL's.

```text
1 · PAGINA'S       de volledige URL van elke gewijzigde pagina, met de tijd erbij
2 · PROFILER       wat hij geleerd heeft, in gewone taal, met het bewijsgetal
3 · ÉÉN VRAAG      eerst WAAROM hij de vraag stelt, dan de vraag, dan drie antwoorden
```

**Zo ziet het eruit, en dit zijn de antwoorden**

```text
"Vandaag gewijzigd: index.html (letters 28, 14:20) · profiel_log.jsonl (6 regels bijgeschreven)"
"Geleerd: je koos vier keer de optie die iets meet. Nog geen gewoonte — dat vraagt drie keer."
"Ik vraag dit omdat je nog nooit iets over geluid gezegd hebt: mag voorlezen uit blijven? 1 ja · 2 nee"

1 ja        → de keuze gaat naar de kern en geldt vanaf de volgende sessie
2 nee       → er verandert niets; de vraag komt niet terug in deze vorm
?           → drie nieuwe vragen uit het profiel
niets       → niets wordt aangenomen, en dat is een volledig antwoord
```

**Nooit aan het einde:** meer dan één vraag · een tabel · een verhaal · een vraag naar ziekte of
lichaam · een vraag waarvan het antwoord al in de kern staat.

---


### 11b · De vraag van deze sessie — binnen de eerste tien laadbeurten

```text
De sessieteller heeft geteld. Staat er "wizard gedaan"? Dan loopt de wizard NIET meer.
In plaats daarvan stelt de profiler precies één vraag uit zijn programma van tien.
```

**De tien vragen, in deze volgorde:**

```text
 1  Wanneer lukt dit het beste voor jou?          ochtend · middag · avond · wisselt per dag
 2  Hoe lang mag een antwoord zijn als het ingewikkeld wordt?   2 · 3 · 5 regels · zo kort mogelijk
 3  Klik je liever, of zeg je liever een nummer?  klikken · zeggen · hangt van de dag af
 4  Kijkt er wel eens iemand met je mee?          ja vaak · soms · nee nooit        (persoonlijk)
 5  Wat mag nooit gebeuren in een gesprek met mij? voorlezen · ongevraagde uitleg ·
                                                   lange teksten · herhalen wat ik weet
 6  Waar stopte een gesprek vroeger omdat het te veel werd?  te veel opties · tekst · vragen · nooit
 7  Hoeveel tijd heb je meestal voor zo'n gesprek?   minder dan 5 min · 5 tot 15 min · zolang als nodig
 8  Wil je dat ik mijn eigen fouten meteen meld?   ja altijd · alleen grote · nee
 9  Mag ik iets voorstellen zonder dat je erom vraagt?  ja graag · alleen op vraag · liever niet
10  Waaraan merk je dat een gesprek goed liep?    ik had mijn antwoord · ik moest niets uitleggen ·
                                                   het was kort · ik durfde verder te vragen
```

**Wat de profiler doet vóór hij de vraag stelt**

```text
1. Kijkt hij of het profiel de vraag al beantwoordt. Zo ja → de vraag overslaan, en de volgende pakken.
2. Past hij de vorm aan het profiel aan: 2 opties bij trage kliks, kortere woorden bij EASY_WORDS,
   geen geluid bij TEXT_FIRST, alles op één scherm bij ANYWHERE.
3. Voegt hij één regel toe met het waarom: "Ik vraag dit omdat…"
4. Stelt hij de vraag na het eerste echte antwoord, niet meteen bij het begin.
5. Logt hij de vraag, het antwoord en het tijdstip. Daarna is het onderwerp dicht.
```

**Wat de gebruiker kan doen**

```text
kiest een antwoord   → het profiel wordt rijker; de vraag komt niet terug
"zeg ik liever niet" → meteen door naar het echte werk, niets opgeslagen (bij vraag 4)
overslaan            → telt als antwoord; het onderwerp komt terug bij een volgende laadbeurt,
                       of niet — dat mag de gebruiker laten
"niet nu"            → de vraag wordt niet opnieuw gesteld in deze sessie
stilte               → de agent wacht, en stelt de vraag niet opnieuw
```

**Vanaf laadbeurt 11:** geen vast programma meer. Alleen nog één gesloten vraag als de profiler een
patroon ziet, en de vraag aan het sessie-einde.

---


### 11c · De vaste controle vóór het afsluiten

Elke sessie eindigt met dezelfde vijf stappen, in deze orde. Niets wordt overgeslagen.

```text
1 PROFIEL      de profiler wordt geraadpleegd en EVALUEERT het profiel van de gebruiker:
               wat bekend is · wat ontbreekt · wat verouderd is (30 dagen) · wat tegenstrijdig is ·
               welke vraag uit de eerste tien als volgende aan de beurt is.
2 RAPPORT      hij meldt in gewone taal wat hij geleerd heeft, met het bewijsgetal erbij.
               Niets geleerd? Dan zegt hij dat ook, zonder verzinsels.
3 PAGINA'S     de volledige URL van elke gewijzigde pagina, met de tijd erbij.
4 ÉÉN VRAAG    binnen de eerste tien laadbeurten: de geplande vraag van die laadbeurt.
               Daarna: alleen een vraag als de profiler iets ziet dat het waard is.
               Altijd eerst WAAROM, dan de vraag, dan drie antwoorden.
5 LOGBOEK      de sessieteller schrijft de laadbeurt weg, en het logboek krijgt zijn regels.
```

**Wat de gebruiker hier kan doen**

```text
antwoorden    → het profiel wordt rijker, en het komt niet terug
overslaan     → niets aangenomen; de vraag mag later terugkomen
"stop"        → de agent sluit af met één regel waar we staan, zonder vraag
niets         → de agent sluit af zonder nog iets te vragen. Stilte is een volledig antwoord.
```

**Nooit vóór het afsluiten:** een tweede vraag · een vraag naar ziekte of lichaam · een verkooppraatje
over de app · een verwijt dat er weinig geklikt is.

---


## M12 · DAARNA — WAT BLIJFT, WAT NIET, EN HOE JE ALLES WIST

```text
WAT BLIJFT            de kern (max 1 scherm) · het logboek (één regel per klik) · het wijzigingenlog ·
                      sessies.jsonl (de teller: nummer, datum, tijd — niets anders)
WAT NIET BLIJFT       gespreksteksten · namen · ziekte · diagnose · gevoelens · wat de gebruiker
                      heeft weggeklikt met "nee"
HOE JE WIST           "wat weet je van mij?" → 3 regels · "vergeet dit" → één regel weg
                      "vergeet alles" → het logboek is leeg en de profiler begint opnieuw
WAT ER MEEREIST       bij de volgende sessie: de kern. Niets anders, en nooit zonder dat de
                      gebruiker het weet.
```

---

## DEEL 3 · DE ANTWOORDMATRIX — ALLES OP EEN RIJ

```text
VRAAG                                  ANTWOORDEN                     GEVOLG
sessiestart                            1 · 2 · 3 · ? · niets           menu, team, veilige standaard, of wachten
geluid                                 1 aan · 2 uit · niets           voorlezen eerste 3 regels, of stilte
wizard 7 vragen                        telkens 1 · 2 · 3 · overslaan   direct toepassen, of niets aannemen
teamkeuze                              één team of "ik weet het niet"  één stem, of één gerichte vraag
eerste taak                            1 · 2 · 3 · 4 · ?               de tak die de gebruiker kiest
elk antwoord van de agent              1 · 2 · 3 · open slot · ?       kiezen, zelf zeggen, of drie nieuwe
?-knop                                 één vraag, dan één antwoord     het profiel wordt rijker, alles gelogd
profiler ziet een patroon              1 ja · 2 nee · ? · niets        toepassen met bron A, of wissen
onderzoeksteam                         vertrouwd · nog niet · onbruikbaar  doorwerken, vragen, of zwijgen
wijziging                              1 ja · 2 nee · "zet terug"      toepassen, laten, of terugdraaien
sessie-einde                           1 · 2 · ? · niets               onthouden voor volgende keer
elk moment, altijd                     hulp · stop · korter · trager  de agent volgt onmiddellijk
```

---

## DEEL 4 · WAT NOOIT GEVRAAGD WORDT — DE VERBODEN LIJST

```text
1. Wat heb je? Welke diagnose? Welk medicijn? Hoe erg is het? — nooit, in geen enkele fase.
2. Hoe voel je je hierover? — nooit. Gevoelens worden niet gevraagd en niet opgeschreven.
3. Mag ik je gegevens bewaren? — alleen één keer, als keuze met 1 ja · 2 alleen gesprek · 3 nee.
4. Twee vragen in één bericht — nooit.
5. Zelfde vraag twee keer — nooit. Wat gekozen is, wordt onthouden.
6. Vragen waarvan het antwoord al in de kern staat — nooit.
7. Vragen die niets veranderen aan hoe we helpen — nooit, ook niet als ze interessant lijken.
8. Vragen die typen, vasthouden, slepen of fijn mikken vereisen — nooit.
```

---

## DEEL 5 · WAAROM DIT SCENARIO ZO STRIKT IS

```text
Elke vraag die we stellen kost de gebruiker energie. Elke vraag die we niet stellen maar zelf
invullen, kost hem vertrouwen zodra we het mis hebben.
Daarom is de volgorde altijd: eerst vragen, dan pas aannemen — en in het midden nooit iets stil.
En daarom staat bovenaan dit bestand het doel: AI-tools toegankelijk maken voor iedere persoon,
met of zonder beperkingen. Elke vraag en elk antwoord in dit scenario moet dat doel dienen.
```

*Onderdeel van een set. Startbestand: `00_START_HIER.md` · overzicht: `INHOUD.md`.
Dit bestand is de kaart van het gesprek, nooit het gesprek zelf.*
